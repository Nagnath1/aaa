package com.example.hp.myapplication.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.adapters.ProductAdapter;
import com.example.hp.myapplication.common.DBHelper;
import com.example.hp.myapplication.models.Product;

import java.util.ArrayList;

import static com.example.hp.myapplication.common.Constants.*;

public class SearchProductActivity extends ActionBarActivity {

    ArrayList<Product> products = new ArrayList<Product>();
    private ListView listView;
    private ProductAdapter adapter;

    EditText editMinimum, editMaximum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_product);

        editMinimum = (EditText) findViewById(R.id.editLowerBound);
        editMaximum = (EditText) findViewById(R.id.editUpperBound);

        listView = (ListView) findViewById(R.id.listView);
        adapter = new ProductAdapter(this, products);
        listView.setAdapter(adapter);
    }

    private void readProductsFromDB(String min, String max) {
        products.clear();
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database = helper.getReadableDatabase();

        // select * from Products where price between (x, y);
        String whereClause = COL_PRODUCT_PRICE + " > ? AND " + COL_PRODUCT_PRICE + " < ?";

        String cols[] = new String[] {COL_PRODUCT_ID, COL_PRODUCT_TITLE, COL_PRODUCT_PRICE, COL_PRODUCT_COMPANY};
        Cursor cursor = database.query(TABLE_PRODUCTS, cols, whereClause, new String[] {min, max}, null, null, null);

        if (!cursor.isAfterLast()) {
            cursor.moveToFirst();

            while (!cursor.isAfterLast()) {

                Product product = new Product();
                product.setProductId(cursor.getInt(cursor.getColumnIndex(COL_PRODUCT_ID)));
                product.setProductTitle(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_TITLE)));
                product.setCompany(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_COMPANY)));
                product.setPrice(cursor.getFloat(cursor.getColumnIndex(COL_PRODUCT_PRICE)));

                products.add(product);

                cursor.moveToNext();
            }
        }

        cursor.close();
        database.close();
        helper.close();

        adapter.notifyDataSetChanged();
    }

    public void searchProducts(View v) {
        readProductsFromDB(editMinimum.getText().toString(), editMaximum.getText().toString());
    }
    public void backButton(View v){
        finish();
    }
}
