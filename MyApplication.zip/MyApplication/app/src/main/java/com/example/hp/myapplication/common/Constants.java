package com.example.hp.myapplication.common;

/**
 * Created by hp on 02-Mar-16.
 */
public class Constants {
    public static final String KEY_PRODUCT_ID = "ProductId";


    // related to Table products
    public static final String TABLE_PRODUCTS = "Products";
    public static final String COL_PRODUCT_ID = "ProductId";
    public static final String COL_PRODUCT_TITLE = "ProductTitle";
    public static final String COL_PRODUCT_COMPANY = "Company";
    public static final String COL_PRODUCT_PRICE = "Price";

}

