package com.example.hp.myapplication.models;

/**
 * Created by hp on 02-Mar-16.
 */
import android.os.Parcel;
import android.os.Parcelable;

public class Product implements Parcelable {
    private int productId;
    private String productTitle;
    private String company;
    private float price;

    public Product() {
    }

    public Product(int productId, String productTitle, String company, float price) {
        this.productId = productId;
        this.productTitle = productTitle;
        this.company = company;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", productTitle='" + productTitle + '\'' +
                ", company='" + company + '\'' +
                ", price=" + price +
                '}';
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.productTitle);
        parcel.writeString(this.company);

        parcel.writeInt(this.productId);
        parcel.writeFloat(this.price);
    }

    public static Parcelable.Creator<Product> CREATOR = new Parcelable.Creator<Product>() {

        @Override
        public Product createFromParcel(Parcel parcel) {
            Product product = new Product();
            product.productTitle = parcel.readString();
            product.company = parcel.readString();

            product.productId = parcel.readInt();
            product.price = parcel.readFloat();
            return product;
        }

        @Override
        public Product[] newArray(int i) {
            return new Product[0];
        }
    };
}

