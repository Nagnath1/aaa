package com.example.hp.myapplication.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.TextView;

import static com.example.hp.myapplication.common.Constants.*;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.common.DBHelper;
import com.example.hp.myapplication.models.Product;

public class ProductDetailsActivity extends ActionBarActivity {

    private TextView textTitle;
    private TextView textCompany;
    private TextView textPrice;
    private TextView textProductId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        Intent intent = getIntent();
        int productId = intent.getIntExtra(KEY_PRODUCT_ID, 0);


        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database =  helper.getReadableDatabase();

        // Select * from Products where productId = 1;
        String query = "Select * from " + TABLE_PRODUCTS + " where " + COL_PRODUCT_ID + " = ?;";

        Cursor cursor = database.rawQuery(query, new String[]{String.format("%d", productId)});

        if (!cursor.isAfterLast()) {
            cursor.moveToFirst();

            Product product = new Product();
            product.setProductId(cursor.getInt(cursor.getColumnIndex(COL_PRODUCT_ID)));
            product.setProductTitle(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_TITLE)));
            product.setCompany(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_COMPANY)));
            product.setPrice(cursor.getFloat(cursor.getColumnIndex(COL_PRODUCT_PRICE)));

            textTitle = (TextView) findViewById(R.id.textProductTitle);
            textCompany = (TextView) findViewById(R.id.textProductCompany);
            textPrice = (TextView) findViewById(R.id.textProductPrice);
            textProductId = (TextView) findViewById(R.id.textProductId);


            textTitle.setText("Title: " + product.getProductTitle());
            textCompany.setText("Company: " + product.getCompany());
            textPrice.setText("Price: " + product.getPrice());
            textProductId.setText("Id: " + product.getProductId());
        }

        cursor.close();
        database.close();
        helper.close();

    }

    public void goBack(View v) {
        finish();
    }
}
