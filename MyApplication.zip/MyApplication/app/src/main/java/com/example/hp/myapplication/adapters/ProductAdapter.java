package com.example.hp.myapplication.adapters;

/**
 * Created by hp on 02-Mar-16.
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.models.Product;

import java.util.ArrayList;

public class ProductAdapter extends ArrayAdapter<Product> {
    private final Context context;
    private final ArrayList<Product> array;

    public ProductAdapter(Context context, ArrayList<Product> array) {
        super(context, android.R.layout.simple_list_item_1);
        this.context = context;
        this.array = array;
    }

    @Override
    public int getCount() {
        return array.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LinearLayout layout = null;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            layout = (LinearLayout) inflater.inflate(R.layout.list_item_product, null);
        } else {
            layout = (LinearLayout) convertView;
        }

        TextView textTitle = (TextView) layout.findViewById(R.id.textTitle);
        TextView textCompany = (TextView) layout.findViewById(R.id.textCompany);

        Product product = array.get(position);
        textTitle.setText("Title: " + product.getProductTitle());
        textCompany.setText("Company: " + product.getCompany());

        return layout;
    }
}

