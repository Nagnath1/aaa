package com.example.hp.myapplication.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.adapters.ProductAdapter;
import com.example.hp.myapplication.common.DBHelper;
import com.example.hp.myapplication.models.Product;

import java.util.ArrayList;

import static com.example.hp.myapplication.common.Constants.*;


public class ProductListActivity extends ActionBarActivity implements AdapterView.OnItemClickListener {

    ArrayList<Product> products = new ArrayList<Product>();
    private ListView listView;
    private ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        listView = (ListView) findViewById(R.id.listView);
        adapter = new ProductAdapter(this, products);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        registerForContextMenu(listView);
    }
    @Override
    protected void onResume() {
        super.onResume();
        readProductsFromDB();
    }
    private void readProductsFromDB() {
        products.clear();
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database = helper.getReadableDatabase();


        String cols[] = new String[] {COL_PRODUCT_ID, COL_PRODUCT_TITLE, COL_PRODUCT_PRICE, COL_PRODUCT_COMPANY};
        Cursor cursor = database.query(TABLE_PRODUCTS, cols, null, null, null, null, null);

        if (!cursor.isAfterLast()) {
            cursor.moveToFirst();

            while (!cursor.isAfterLast()) {

                Product product = new Product();
                product.setProductId(cursor.getInt(cursor.getColumnIndex(COL_PRODUCT_ID)));
                product.setProductTitle(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_TITLE)));
                product.setCompany(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_COMPANY)));
                product.setPrice(cursor.getFloat(cursor.getColumnIndex(COL_PRODUCT_PRICE)));

                products.add(product);

                cursor.moveToNext();
            }
        }

        cursor.close();
        database.close();
        helper.close();

        adapter.notifyDataSetChanged();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Add");
        menu.add("Search");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("Add")) {
            startActivity(new Intent(this, AddProductActivity.class));
        } else if (item.getTitle().equals("Search")) {
            startActivity(new Intent(this, SearchProductActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("Options");
        menu.setHeaderIcon(R.drawable.ic_launcher);

        menu.add("Delete");
        menu.add("Update");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        final AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        if (item.getTitle().equals("Delete")) {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Confirmation");
            builder.setMessage("Are you sure you want to delete this product?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    DBHelper helper = new DBHelper(ProductListActivity.this);
                    SQLiteDatabase database = helper.getWritableDatabase();

                    Product product = products.get(info.position);
                    // delete from Products where productId = product.getProductId();

//                    String whereClause = COL_PRODUCT_ID + " = " + product.getProductId();
//                    database.delete(TABLE_PRODUCTS, whereClause, null);
//
//
                    String whereClause = COL_PRODUCT_ID + " = ?";
                    database.delete(TABLE_PRODUCTS, whereClause, new String[] { String.format("%d", product.getProductId()) });

                    database.close();
                    helper.close();

                    readProductsFromDB();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            builder.create().show();

        } else if (item.getTitle().equals("Update")) {

            Intent intent = new Intent(this, UpdateProductActivity.class);
            Product product = products.get(info.position);
            intent.putExtra(KEY_PRODUCT_ID, product.getProductId());
            startActivity(intent);

        }

        return super.onContextItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int index, long l) {
        Product product = products.get(index);

        Intent intent = new Intent(this, ProductDetailsActivity.class);
        intent.putExtra(KEY_PRODUCT_ID, product.getProductId());
        startActivity(intent);
    }
}
