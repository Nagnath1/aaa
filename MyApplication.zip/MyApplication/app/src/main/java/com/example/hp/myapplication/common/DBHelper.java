package com.example.hp.myapplication.common;

/**
 * Created by hp on 02-Mar-16.
 */
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static com.example.hp.myapplication.common.Constants.*;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "productsdb.sqlite";
    private static final int DB_VERSION = 1; // > 0

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //String query = "CREATE TABLE Products (ProductId integer primary key autoincrement, ProductTitle TEXT, Company TEXT, Price float);";

        String query = "CREATE TABLE " + TABLE_PRODUCTS + " ( "
                + COL_PRODUCT_ID + " integer primary key autoincrement, "
                + COL_PRODUCT_TITLE + " text, "
                + COL_PRODUCT_COMPANY + " text, "
                + COL_PRODUCT_PRICE + " float);";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}

