package com.example.hp.myapplication.activities;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.common.DBHelper;

import static com.example.hp.myapplication.common.Constants.*;

import java.util.ArrayList;

public class AddProductActivity extends ActionBarActivity {

    EditText editTtile, editPrice;
    Spinner spinnerCompany;

    ArrayList<String> companies = new ArrayList<String>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        companies.add("Apple");
        companies.add("Motorola");
        companies.add("Samsung");
        companies.add("lenovo");
        companies.add("Microsoft");
        companies.add("Google");

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, companies);
        spinnerCompany = (Spinner) findViewById(R.id.spinnerCompany);
        spinnerCompany.setAdapter(adapter);

        editTtile = (EditText) findViewById(R.id.editTitle);
        editPrice = (EditText) findViewById(R.id.editPrice);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Save");
        menu.add("Cancel");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("Save")) {
            // insert into table

            DBHelper helper = new DBHelper(this);
            SQLiteDatabase database = helper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_PRODUCT_TITLE, editTtile.getText().toString());
            values.put(COL_PRODUCT_COMPANY, spinnerCompany.getSelectedItem().toString());
            values.put(COL_PRODUCT_PRICE, Float.parseFloat(editPrice.getText().toString()));

            database.insert(TABLE_PRODUCTS, null, values);

            database.close();
            helper.close();
            finish();
        } else if (item.getTitle().equals("Cancel")) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
