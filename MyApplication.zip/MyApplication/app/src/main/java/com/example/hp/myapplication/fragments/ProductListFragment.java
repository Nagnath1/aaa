package com.example.hp.myapplication.fragments;

/**
 * Created by hp on 02-Mar-16.
 */
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.hp.myapplication.adapters.ProductAdapter;
import com.example.hp.myapplication.R;
import com.example.hp.myapplication.models.Product;

import java.util.ArrayList;

public class ProductListFragment extends Fragment {

    ArrayList<Product> products = new ArrayList<Product>();
    private ListView listView;
    private ProductAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.fragment_product_list, null);

        products.add(new Product(1, "product1", "company1", 100f));
        products.add(new Product(2, "product2", "company2", 200f));

        listView = (ListView) layout.findViewById(R.id.listView);
        adapter = new ProductAdapter(getActivity(), products);
        listView.setAdapter(adapter);
        return layout;
    }
}

