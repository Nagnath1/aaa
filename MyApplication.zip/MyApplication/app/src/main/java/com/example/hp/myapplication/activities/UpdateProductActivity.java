package com.example.hp.myapplication.activities;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.hp.myapplication.R;
import com.example.hp.myapplication.common.DBHelper;
import com.example.hp.myapplication.models.Product;

import  static com.example.hp.myapplication.common.Constants.*;
import java.util.ArrayList;

public class UpdateProductActivity extends ActionBarActivity {

    EditText editTtile, editPrice;
    Spinner spinnerCompany;

    ArrayList<String> companies = new ArrayList<String>();
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        companies.add("Apple");
        companies.add("Google");
        companies.add("Microsoft");

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, companies);
        spinnerCompany = (Spinner) findViewById(R.id.spinnerCompany);
        spinnerCompany.setAdapter(adapter);

        editTtile = (EditText) findViewById(R.id.editTitle);
        editPrice = (EditText) findViewById(R.id.editPrice);

        int productId = getIntent().getIntExtra(KEY_PRODUCT_ID, 0);

        String query = "SELECT * FROM " + TABLE_PRODUCTS + " WHERE " + COL_PRODUCT_ID + " = ?";
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor cursor = database.rawQuery(query, new String[]{String.format("%d", productId)});

        if (!cursor.isAfterLast()) {
            cursor.moveToFirst();

            Product product = new Product();
            product.setProductId(cursor.getInt(cursor.getColumnIndex(COL_PRODUCT_ID)));
            product.setProductTitle(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_TITLE)));
            product.setCompany(cursor.getString(cursor.getColumnIndex(COL_PRODUCT_COMPANY)));
            product.setPrice(cursor.getFloat(cursor.getColumnIndex(COL_PRODUCT_PRICE)));

            editTtile.setText(product.getProductTitle());
            editPrice.setText(String.format("%f", product.getPrice()));

            if (product.getCompany().equals("Apple")) {
                spinnerCompany.setSelection(0);
            } else if (product.getCompany().equals("Google")) {
                spinnerCompany.setSelection(1);
            } else if (product.getCompany().equals("Microsoft")) {
                spinnerCompany.setSelection(2);
            }
        }

        cursor.close();
        database.close();
        helper.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Update");
        menu.add("Cancel");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("Update")) {

            DBHelper helper = new DBHelper(this);
            SQLiteDatabase database = helper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_PRODUCT_TITLE, editTtile.getText().toString());
            values.put(COL_PRODUCT_PRICE, Float.parseFloat(editPrice.getText().toString()));
            values.put(COL_PRODUCT_COMPANY, spinnerCompany.getSelectedItem().toString());

            // update ..... where productId = 1
            String whereClause = COL_PRODUCT_ID + "=?";

            int productId = getIntent().getIntExtra(KEY_PRODUCT_ID, 0);
            database.update(TABLE_PRODUCTS, values, whereClause, new String[]{String.format("%d", productId)});

            database.close();
            helper.close();

            finish();
        } else if (item.getTitle().equals("Cancel")) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
